package kr.spring.service;

import kr.spring.entity.Member;

public interface MemberService {

	public void join(Member vo);
	
	
}
